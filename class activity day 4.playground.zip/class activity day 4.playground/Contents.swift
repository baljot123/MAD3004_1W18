//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

struct address{
    var street: String = "265 Yorkland BLvd"
    var area : String = "North York"
    var postalcode: String = "L7Y4!!"
}

class person{
    var firstname: String = "Baljot"
    var lastname: String = "Singh"
    var age: Int = 50
    var address1 = address()
    var totalamount: Int = 2000
    
}
let person1 = person()
print("first name:", person1.firstname)
print("lastname :",person1.lastname)
print(person1.address1)
print("age :",person1.age)
print("totalamount :",person1.totalamount)
