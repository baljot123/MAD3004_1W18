//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


var num: Int=1
var num1:Int=5
if(num < 10)
{
    for i in 1...10
    {
        num1 = 5 * i
        print("5","*",i,"=",num1)
    }
}
else {
    let n:Int = num + 1
    for  i in 1..<n {
        num1 = num1 * i
    }
    
}

var a1:[Int]
a1 = [1,2,3]
var sum1 = 0
for i in a1{
    sum1 = sum1 + i;
}
print("sum1",sum1)

let strOne = """
This is a first line
This is another line
This is one more line
Ok. Enough of lines 🤓
"""
print(strOne)

var mood = " "
let heart = "\u{1F496}" //\u is used to use unicode in swift
mood = "happy"
if mood.isEmpty{   //checking the string is empty or not
    print("cheer up")
}
else{
    print(heart)
}
 mood += " chherful joyful" //the value would be changed as  mood is declared as a variable
print(mood)


//heart += "Be happy" // we cannot change value as heart is declared as let
//we cannot execute the above statement
var firstName = String()
firstName = "abc"
print(firstName)
for i in  firstName{ //this loop will print all the characters that are present in string
    print(i)
    
    let initial : Character = "J"  // character is used to declare a char variable
    firstName.append(initial)  // .append is used to append an existing string with some characters
    
    print(firstName)
    
     print("firstname is \(firstName) which is \(firstName.count) characters long. ")
 // .count is used to find the length of string like stringname.count
    
    
    let Initial: Character = "N"
    
    firstName.append(Initial)
    print(firstName)
    
    print("firstname is \(firstName )which is \(firstName.count) characters long. ")
    
    print("start Index :",[firstName.startIndex])
    //print("end Index:",FirstName[firstName.endIndex]) // no chara ter bcz no null chr
    print("before end Index:",firstName[firstName.index(before: firstName.endIndex)])
    print("after start Index:",firstName[firstName.index(after: firstName.startIndex)])
    print("5th character:",firstName[firstName.index(firstName.startIndex,offsetBy: 4)])

    print("3rd from last character:",firstName[firstName.index (firstName.endIndex ,offsetBy: -3)])
    
    let idx = firstName.index(firstName.startIndex,offsetBy: 3)
    print("fourth character",firstName[idx])
    
    var language = "Swift"
    print ("language:",language)
    language.insert(contentsOf : "java", at: language.endIndex)
    

print("language",language)



/*var length = firstName.count

print(length)

for i in 1...5 {
    print(i)
    
    print(firstName)
    

}*/

let range = language.startIndex..<language.endIndex
language.removeSubrange(range)
print("language removesubrange: ",language)

let gretting = "Happy Holidays"
let index = gretting.index(of: " ") ?? gretting.endIndex
let start = gretting[..<index]
let newGreet = String(start)
    print("sub string : ",newGreet)
    print("String in uppercase : ",newGreet.uppercased())
    if(newGreet == newGreet.uppercased()){
        print("Equal")
    }
    else{
        print("Not equal")
    }

    let grade : String?
    //grade = "A"
    let finalGrade = grade ?? "F"
    
    if(finalGrade.isEmpty){
        print("Not graded yet")
    }
    else{
        print("grade: ",finalGrade)
    }
}






