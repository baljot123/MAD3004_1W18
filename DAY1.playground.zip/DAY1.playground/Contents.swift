//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print(str)
//use terminator to terminate the line
print("This is our string : \(str)", terminator:" ")
//use separator for separating multiple prompts

print("1","2","3","4","5",separator:"..")

var n1=10
print("number 1:",n1,"string :",str)
var n2=20
print("number 2:",n2)
var sum = n1+n2
print("sum of n1+n2=",sum)
print("sum=",n1+n2)
/*
//n1 = "test"
//print("n1:",n1)
*/
//assigning values to variables
var a:Int=10
print("a:",a)
var greet:String = "Good Morning"
print("Greetings :",greet)

var s1:Float=10.098
print("s1 :",s1)
var emoji = "😎";
print("stay \(emoji) cool")

let pi=3.14
//pi=3.190
print("pi :",pi)

//var pi=10

let mynum:Int? //optional
mynum=nil
if mynum != nil{
    print("mynum : ",mynum!)
}
else{
    print("mynum is nil")
}

let possiblenumber = "hello" //"hello"
let convertednumber:Int?
convertednumber = Int(possiblenumber)

if convertednumber != nil{
    print("converted number :",convertednumber!)
}
else{
    print("converted number is nil")
}


for i in 1..<5{
    print("i = ",i)
}
let languages:[String]
languages = ["English","spanish","french"]

for i in languages{
    print("language :",i)
}
/*let a1:[Int]
a1 = [1,2,3]
let b1:[Int]
b1 = [4,5,6]
for i in a1{
    for i in b1{
    print("sum of arrays",a1[i]+b1[i])
    }}*/

var answer: Int = 1
for _ in 1...5{
    answer *= 5;
}
print("answer = ",answer)

var Interval:Int = 5
for i in stride(from: 0, to:50, by: Interval){
    print(i," ",terminator: " ")
    
}

/*var j = 1
while(j<5)
{
    
    print("j= \(j)")
    j = j+1
    break;
}

repeat{
    print("repeat : ",j)
    j = j+2
}while (j<=10)



var k: Int = 5
var factorial: Float = 1
if k>10{
    factorial*k =
}
*/
var num = 10
Switch num {
Case 100 :
    print("value of num is 100")
    Case 10,15 :
    print("value of num is either 10 or 15")
    case 5 :
    print("value of num is 5")
    default
}

