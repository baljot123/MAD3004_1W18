//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//CLOSURES IN SWIFT

//SORTED CLOUSERS

var months = [4,3,1,5,6,2]
print(months.sorted())

func reverse(_ s1: Int, _ s2: Int) -> Bool { //returs true and false value compares first and second value if value is true the position remains same otherwise it automaticcaly swaps and start comparing from first one
    return s1 > s2

}
var reversedMonths = months.sorted(by: reverse)
print("reversed months",reversedMonths)

func increasing(_ s1: Int , _ s2: Int) -> Bool{
    return s1 < s2
}
var increasingMonths = months.sorted(by: increasing)
print("incresingmonths",increasingMonths)


//closure expression syntax
/*
 { (parameter) ->return type in statement)}
 
 */
var reverseClosure = months.sorted(by: {
    (s1: Int, s2: Int) -> Bool in
    return s1 > s2
})
print("reversedclousre",reverseClosure)



//inferring parameter types from context

var inferTypes = months.sorted(by: {
    (s1, s2)
in return s1 < s2//(s1,s2) in s1<s2 // implicit return
})
    
print("inferTypes :",inferTypes)

// shorthand arguments name

print("shorthand argument :", months.sorted(by: {$0 < $1}))

//operator methods
print("opertator methods : ", months.sorted(by: <))


var three = [1,2,3,4,5,6,7,8,9,12,15]
print(three)

var modThree = three.filter({ $0 % 3 == 0})//we are applying filter and wants to retrieve elements which are divisible by 3

print("modthree ",modThree)



var even = [1,2,3,4,5,6,8,12]
even = even.filter({ $0 % 2 == 0})
print(even)


//nested function clossure

func makeincrementer(forincrement amount: Int) -> () ->Int{
    var runningTotal = 0
    func incrementer() -> Int {
        runningTotal += amount
        return runningTotal
    }
    return incrementer
}
let incrementByTen = makeincrementer(forincrement: 10)
print("first call: ",incrementByTen())
print("second call :",incrementByTen())
print("third call: ",incrementByTen())


let incrementBySeven = makeincrementer(forincrement: 7)
print("increment by seven 1:" ,incrementBySeven())
    print("increment by seven 2 :",incrementBySeven())

print("fourth call :", incrementByTen())

//closures are reference type

let incrementBySevenAgain = incrementBySeven
print("Increment by sveven 3 : ",incrementBySevenAgain())

//Autoclosures

var errorlist = [404,414,402,431,455,440]

print("total errors : ",errorlist.count)

let debugger = { errorlist.remove(at: 0)}
print("Total Errors:",errorlist.count)
print("now solving \(debugger())!")
print("Total Errors :",errorlist.count)
print("error list:",errorlist)

/* same behaviour of delayed evaluation can be achieved when you pass a closure as an argument*/



func solve(error debugger: @autoclosure () -> Int){
    print("now solving \(debugger()) !")
}
solve(error :errorlist.remove(at:0))
print("error list",errorlist)

