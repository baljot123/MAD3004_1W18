//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


class tutorial: Codable
{
    let title: String
    let author: String
    let editor: String
    let type: String
    let publishdate: Date
    
    init(title: String,author: String,editor: String,type: String,publishdate: Date)
    {
        self.title = title
        self.author = author
        self.editor = editor
        self.type = type
        self.publishdate = publishdate
    }
    
}

let Tutorial = tutorial(title: "Whats new in swift 4?", author: "Cosmin pupaza",editor: "Simon ng",type: "Swift",publishdate: Date())

let encoder = JSONEncoder()
let data = try encoder.encode(Tutorial)
let jsonstring = String(data: data , encoding: .utf8)
print(jsonstring ?? "")

let decoder = JSONDecoder()
let article = try decoder.decode(tutorial.self, from: data)
let info = "\(article.title) \(article.author) \(article.editor) \(article.type) \(article.publishdate)"

print(info)


//MATCHING EXPRESSIONS



