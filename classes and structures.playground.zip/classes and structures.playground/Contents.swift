//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

//classes

struct project{
    var title = ""
    var hours = 0
    
    func display(){
        print("project title :",title)
        print("total work houws requied :",hours)
    }
}

//DECLARING INSTANCE OF STRUCTURE
var LMSProject = project(title: "Moodle",hours :200)
print(LMSProject)

LMSProject.display()

LMSProject.hours = 300
print(LMSProject)
LMSProject.display()

//decxlaring class
class Manager {
    var name : String = ""
    var productOwner: Bool = true
    var currentprojects = project()

}




//creating instance of class

let mgrCanada = Manager()
mgrCanada.name = "ABC"
mgrCanada.productOwner = true
mgrCanada.currentprojects = project(title: "sales reporting",hours: 20)


print(mgrCanada.name)
print(mgrCanada.productOwner)
print(mgrCanada.currentprojects)


//structures are value types
struct address{
    var street = "265 Yorkland blvd"
    var city = "North york"
    var postalcode = "M1H1Y1"
}
var lambton = address ()
print("lambton:",lambton)

var cestar = lambton //structure are value types they only once chng values

print("cestar: ",cestar)

cestar.street = "271 yorkland blvd"
cestar.postalcode = "M1H3W3"
print("cestar",cestar)
print("lambton",lambton)// the values remains same

//classes are reference type

class institute{
    var street = "265 yorkland blvd"
var city = "north york"
var postalcode="M1H131"

}
var mylambton = institute()
print("street",mylambton.street)
print("city",mylambton.city)
print("postalcde",mylambton.postalcode)

var mycestar = mylambton
print("street:",mycestar.street)
print("city",mycestar.city)
print("postal",mycestar.postalcode)

mycestar.street = "290 yorkland blvd"
mycestar.postalcode = "lhy75657"
print(mycestar.street)
print(mylambton.street)

//identical to ===

if mylambton === mycestar{

    print("both are same")

}
else {
    print("not ssme");
}

var yourcestar =  institute()
if yourcestar === mycestar {
    print("yourcestar and mycestar are same")
}
else{
    print("yourcestar and mycestar are  not same")
}

