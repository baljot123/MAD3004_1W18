//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"
var a = [10,20,30,40,50]

print(a[0])
print("a : ",a)


let j1=[10,20]
print("j1 : ",j1)

//use methods to add values
var b = [Int]();
print("size of array b : \(b.count)")
b.append(100)
print("b[0] : \(b[0])")

b.append(1000)
print("b :",b)
b[0] = 1000
print(b[0])



var num1=[Int](repeating : 1, count : 3)
print("num1 array : \(num1)")
var num2=[Int](repeating : 5, count : 3)
print("num2 array : \(num2)")

var numMerge = num1 + num2

print("numMerge array : \(numMerge)")


var c = [Any] ()
print("size of array c : \(c)")
c.append(100)
c.append(19.876)
c.append("journey")
print("c : \(c)")

var x = a[1...3]
for t in x{
    print("x : \(t)")
    
//string array and for-each with (key,value)
    
    var shoppinglist : [String] = ["Bread","milk"]
    for (index,value) in shoppinglist.enumerated() // to access index and value we have to change its type to enumerated
    {
        print("Item \(index): \(value)")
    }
    
    
    if shoppinglist.isEmpty{
        print("the shopping list is empty")
    }
    else{
        print("shopping list is not empty")
    }
    shoppinglist.append("Flour")
    
    print("shopping list aerrauy : \(shoppinglist)")
    
    shoppinglist += ["choclate spread", "cheese" ," Butter" ]
    print(shoppinglist)
    //shoppinglist[4...6] = ["BANANAS" ,"apples"]
    
    shoppinglist.insert("Maple Syrup",at:0)
    let Maplesyrup = shoppinglist.remove(at: 2)
    let apples = shoppinglist.removeLast()
    print("shoppinglist: \(shoppinglist)")
    
    
    //SET
    //DECLARING SET
    
    var grades: Set<Character> = []
    grades.insert("A")
    grades.insert("B")
    print("grades : \(grades)")
    print("grades no of elemrnts",grades.count)
    
    
    //var gradeType:Set <Any> =[] //set does not contain different values
    
    var  favouritegenres: Set<String> = ["Rock", "Classical","Hip hop"]
    print("favouritegenres : \(favouritegenres)")
    
    print("i have \(favouritegenres.count) favourite music genres")
    
    if favouritegenres.isEmpty{
        print("as far as music goes, I'm not picky")
    }
    else{
        print("i have particular music preferences")
    }
    favouritegenres.insert("Jazz")
    print("favgeneres : \(favouritegenres)")
    
    if let removedgenre = favouritegenres.remove("Rock"){
    print("\(removedgenre)? i am over it")
    }
    else{
        print("i never much")
    }
    print("\(favouritegenres)" )
    for genre in favouritegenres.sorted(){
        print("\(genre)")
        
        
        //FUNCTIONS OF SET
        
        let odddigits: Set = [1,3,5,7,9]
        let evendigits: Set = [0,2,4,6,8]
        let singledigitprimenumbers: Set = [2,3,5,7]
        
        print(odddigits.union(evendigits).sorted())
        print(odddigits.intersection(evendigits).sorted())
        print(odddigits.subtracting(singledigitprimenumbers).sorted())
        print(odddigits.symmetricDifference(singledigitprimenumbers).sorted())//when both have same values
        
        let houseanimals : Set = ["🐻","🐱"]
        let farmanimals : Set = ["🐻","🐱","🐴","🦁"]
        let cityanimals : Set = ["🐝"]
   print(houseanimals.isSubset(of: farmanimals))
        print(farmanimals.isSuperset(of: houseanimals))
        print(farmanimals.isDisjoint(with: cityanimals))
    }
    
}



