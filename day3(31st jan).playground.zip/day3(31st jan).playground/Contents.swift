//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"



var namesofIntegers = [Int: String]() //names of integrs is an empty [Int:string dictionary]
namesofIntegers[16] = "Sixteen" //names of integers now contain 1 key value pair
print("names of integers ; \(namesofIntegers.count) elements")
namesofIntegers[28] = "Twenty Eight"

print("dictionary contains \(namesofIntegers.count) elements")
print("dictionary :",namesofIntegers)

namesofIntegers = [:] //names of integers is once again an empty dictionary of type [Int:String]
print("dictionary contains \(namesofIntegers.count) elements")
print("names of integers",namesofIntegers)

if(namesofIntegers.isEmpty){
print("dictionary is empty")
}
else{
print(namesofIntegers)
}

var airports: [String: String] = ["YYZ": "toronto pearson international airport","DUB":"Dublin"]
print("airports \(airports)")
print("the airport dictionary contains \(airports.count) items")//print the airports dictionary with two values

 airports["LHR"] = "London Heathrow" //the value for lhr is changed to london heathrow

airports["YYZ"] = "TP International" //changing the values with the help of key YYZ
airports["AMD"] = "SVP International"
print("airports :",airports)


let oldValue = airports.updateValue("Dublin airport", forKey: "DUB")
print("the old value for DUB was \(oldValue)")//prints the old value for dub was Dublin //optional because it can be possible that foe r key value is nil or not in list
if let airportName = airports["AMD"]{
print("the value of the airport is \(airportName)")
}
else{
    print("airport is not in airport ductionary")
}

airports["MARS"] = nil
print("airports : \(airports)")

if let removedvalue = airports.removeValue(forKey: "DUB"){
    print("the removed airports name is : \(removedvalue)")
}
else {
    print("the airports dictionary does not contain a value for dub") //prints the removed airpport is Dublin airport
}


for(airportcode , airportName) in airports {
    print(airportcode,airportName)
}
for airportcode in airports.keys {
    print("Airportcodes : \(airportcode)")
}


let airportCodes = [String](airports.keys)
print("airportcodes : \(airportCodes)")

let airportNames = [String](airports.values)
print("airportnames : \(airportNames)")


//<KEY,VALUE> pairs
var d1 : Dictionary<String , String> = ["India":"Hindi","canada":"English"]
print(d1)
print(d1.description)
print(d1["India"]!) //cannot contain nilll value
print(d1["canada"]!)
print("USA")
d1["china"] = "Mandrain"
for(k,v) in d1{
    print("\(k) -> \(v)")
}

//Dictionary with any value type

var d3 = [String: AnyObject] ()
d3["firstName"] = "Baljot" as AnyObject
d3["lastNAme"] = "Sansoya" as AnyObject
d3["age"] = Int(50) as AnyObject
d3["salary"] = nil
print("d3",d3)

//Declaring Tuples
var x = (10,20,"Baljot")
print(x.0)
print(x.1)
print(x.2)

let http404Error = (404,"Not Found")
print(http404Error)
let (statusCode , statusMessage) = http404Error
print("statuscode",statusCode)
print(statusMessage)
let(codeOnly, _) = http404Error
print("codeonly",codeOnly)

let errorDescription = (Code : 404, Message : "Not Found")

print(errorDescription.Code , errorDescription.Message)



//FUNCTIONS
//SIMPLE DECLARATION

func add()
{
    print("I am in user Defined Function")
}
add()

func add( _ n1:Int,_ n2:Int){ //we can avoid arguments by  writing _
    var sum : Int
    sum = n1 + n2
    print("sum",sum)
}

add( 10,  20)
//add(10,20) argument labels are necessary
//add(n2:20,n1:40) proceed n1 first
//Single parameter
func welcome(name: String)
{
    print("Hello,\(name)")
}


func sub(a:Int, _ b:Int)
{
    let c = a - b
    print("sub: \(c)")
}
sub(a: 30,10)
//single return t

func mul(a:Int,b:Int) -> Int{ //return type declaration

let c = a * b
    return c
}

var c = mul(a:10,b:20)
print(c)

//multi return values and define new label

func swipe(number1 a: Int, b:  Int) -> (Int , Int)
{
    //function parametres are constant by default
    // var temp =a
    //a=b
    //b=temp
    return (b , a)
}
var (a,b) = swipe(number1: 10 , b: 20)
print("a :\(a) , b : \(b)")
(_,c) = swipe(number1: 10 , b : 20)
print (c)

//inout concept

func swipe(aa: inout Double, bb: inout Double)
{
    let temp = aa
    aa = bb
    bb = temp
}
var z = 8.0, y = 9.0
swipe(aa:&z , bb:&y)
print(z,y)


//DEFAULT PARAMETERS

func simpleInterest(amount:Double, noOfYears: Double,rate:Double = 4.0) -> Double
{
    let si = amount * rate * noOfYears / 100
    return si
}
print("simple interest: \(simpleInterest(amount: 1000, noOfYears: 5))")
print("simple interest : \(simpleInterest(amount: 1000,noOfYears: 5,rate: 10.0))")


//VARIADIC PARAMETERS
func display(n:Int...) //when we know what type of data we are passing but not how much like int...
{
    for i in n {
        print(i)
    }
}
display(n: 1,2,3,4,5)
display(n: 10,20,30)



//PASSING ARRAY AS PARAMETER

func display(numberValues: Int, parameters:[Int]...)
{
    print("Number of values \(numberValues)")
    for i in parameters{
        print("i: \(i)")
        
        
    }
}

var arr = [1,2,3,4,5]
//display(display(numberValues: 3, parameters: arr,arr,arr))


func display(arrayList:[Int]...) -> [Int]
{
    var array1 = arrayList[0]
    var array2 = arrayList[1]
    var result = [Int]()
    
    if array1.count == array2.count{
        for i in 0..<array1.count{
            result.append(array1[i] + array2[i])
        }
        
            return result
        
        var a1 = [1,2,3,4,5]
        var a2 = [10,11,12,13,14]
        var a3 = display(arrayList:a1,a2)
        print(a1)
        print(a2)
    }
}

