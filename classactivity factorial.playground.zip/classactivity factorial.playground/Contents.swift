//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

func factorial(num: Int) ->Int{
    
    if num == 1 {
        return 1
    }
    else{
        return num * factorial(num: -1)
    }
}
let z = 4
let result = factorial(num: z)
print("teh factorial of \(z) is \(result)")
